from django.apps import AppConfig


class OrderApiConfig(AppConfig):
    name = 'order_api'
